# HTML5-BLE-eAR
HTML5 BLE Example with e-AR sensor

This is a simple example program which demonstrate how HTML5 can connect to BLE devices.
It will only work with Chrome on MAC or Chrome on Android devices. 
However, some how it cannot detect the BLE device with Chrome on Windows....

You can try it out via the following website:
https://www.bennyplo.com/bennylo/BLE%20Example/
